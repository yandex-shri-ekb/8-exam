({
    mustDeps: [
        {
            elems: ['desc', 'item', 'items', 'link', 'name', 'photo', 'sep'],
        },
    ],
})