({
    mustDeps: [
        { elems: ['image'] },
    ],
})
