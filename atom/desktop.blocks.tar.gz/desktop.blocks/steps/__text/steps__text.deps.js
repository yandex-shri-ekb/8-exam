({
    mustDeps: [
        {
            mods: {
                pull: ['right', 'left'],
            },
        },
    ],
})
