({
    mustDeps: [
        {
            mods: {
                num: ['one', 'two', 'three', 'four'],
            },
        },
    ],
})
