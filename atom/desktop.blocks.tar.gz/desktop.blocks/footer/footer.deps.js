({
    mustDeps: [
        {
            elems: [
                'copyrights',
                'line',
                'menu',
                'menu-item',
                'menu-link',
                'text',
            ],
        },
    ],
})
