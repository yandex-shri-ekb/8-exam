({
    mustDeps: [
        { elems: ['flag', 'atoms', 'title'] }
    ]
})
