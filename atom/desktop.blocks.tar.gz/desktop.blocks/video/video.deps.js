({
    mustDeps: [
        {
            elems: ['link', 'link-image', 'text'],
        }
    ],
})