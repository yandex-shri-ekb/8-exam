({
    shouldDeps: [
        { elems: ['close', 'content', 'inner', 'shadow', 'va-helper', 'iframe'] },
        { mods: { showed: 'yes' } }
    ]
})
