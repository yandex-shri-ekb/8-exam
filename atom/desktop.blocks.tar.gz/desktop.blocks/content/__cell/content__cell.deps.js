({
    mustDeps: [
        {
            mods: {
                type: ['aside', 'footer', 'header', 'history'],
            },
        },
    ],
})